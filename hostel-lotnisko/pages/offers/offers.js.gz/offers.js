import "./offers.less";

import "../../components/widget-search/widget-search.js";
import "../../components/filters/filters.js";
import "../../components/side-map/side-map.js";
import "../../components/side-payments/side-payments.js";
import "../../components/offers-list/offers-list.js";
import "../../components/distinguished/distinguished.js";