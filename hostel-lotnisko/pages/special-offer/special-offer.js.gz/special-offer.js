// load style for page - DO NOT CHANGE !
import "./special-offer.less";

import "../offer/offer.js";
import "../../components/offer-bundle/offer-bundle.js";
