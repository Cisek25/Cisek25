// load style for page - DO NOT CHANGE !
import "./news.less";

// template components 
import "../../components/news-list/news-list.js";
import "../../components/news-item/news-item.js";
import "../../components/distinguished/distinguished.js";

