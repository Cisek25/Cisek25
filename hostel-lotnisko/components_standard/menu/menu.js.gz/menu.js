import autoComplete from "./autocomplete/autocomplete";

/**
 * Build menu with dots for additional content.
 * 
 * onOff - if false, destroy 
 */
function dots_menu(onOff = true) {

    //before js run, display menu in a row
    // remove jump efect 
    $(".navbar-nav-notloaded").removeClass("navbar-nav-notloaded");

    const jMenu = $("#navbar > ul");
    if (!jMenu.length) return;

    let jMenuOverflow = $("li.menuOverflow");

    // destry 
    if (jMenuOverflow.length) {
        jMenu.append(jMenuOverflow.find("li"));
        jMenuOverflow.remove();
        jMenuOverflow = [];

    }
    // destry - quit 
    if (!onOff)
        return false;

    // build menu 
    let jMenuElements = $("#navbar > ul > li");
    const menuMaxWidth = jMenu.width();

    if (menuMaxWidth > 0) {
        let mSum = 0;
        jMenuElements.each(function () {
            mSum += $(this).outerWidth();
        });

        // stop if fits 
        while (mSum > menuMaxWidth) {

            if (!jMenuOverflow.length) {
                jMenu.append($('<li class="menuOverflow">'));
                jMenuOverflow = $("li.menuOverflow");
                jMenuOverflow.append($("<span>...</span>"));
                jMenuOverflow.append($('<ul class="menuOverflow">'));
            }
            jMenuElements = $("#navbar > ul > li:not(.menuOverflow)");
            jMenuOverflow.find("ul.menuOverflow").append(jMenuElements.last());
            jMenuElements = $("#navbar > ul > li");
            mSum = 0;
            jMenuElements.each(function () {
                mSum += $(this).outerWidth();
            });
        }
    }
}

app_book.run(function navbarNav() {

    $('header').on('click', ".navbar-toggler", function () {
        $('#navbar').slideToggle();
        return false;
    });

}, [1, 2], "#navbar"); // TODO - ONCE 


app_book.run(function navbarNav() {

    dots_menu(false);

}, [1, 2], "#navbar");


app_book.run(function navbarNav() {

    dots_menu(true);

}, [3, 4], "#navbar");



app_book.run(function navsearch() {
    
    $(".flags a").click(function(){
        $.cookie('langChange', 'y');
    })

}, "all", ".flags a");
