
app_book.run(function () {
    $('a.to-offer-prices').on('click', function () {
        // $('.cennik').show();
        $('html, body').animate({
            scrollTop: $('.offer-prices').offset().top - 25
        }, 1000);
        return false;
    });
}, 'all', '.to-offer-prices');