@import "../app.bundle.less";
@import "../offers.bundle.less";
@import "../_generate_less_entrypoints.js";