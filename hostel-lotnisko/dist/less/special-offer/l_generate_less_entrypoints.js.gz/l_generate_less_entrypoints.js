@import "../app.bundle.less";
@import "../special-offer.bundle.less";
@import "../_generate_less_entrypoints.js";