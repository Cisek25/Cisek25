app_book.run(function showFilters() {
  $('#show_filters').click(function showFiltersClick() {
    $('#menu_filter').slideToggle(300);
  });
}, 'all', '#show_filters');


app_book.run(function menuFilter() {
  $('#menu_filter input').on('change', function menuFilterChange() {
    const filtersObj = {};
    $('#menu_filter .filter_items').each(() => {
      const $this = $(this);
      if ($this.find('input:checked').length) {
        const filterName = $this.find('input[type="checkbox"]').attr('name').replace('[]', '');
        const filterValues = [];
        $this.find('input:checked').each(() => {
          const $filter = $(this);
          if ($filter.data('from') && $filter.data('to') !== '') {
            filterValues.push({
              from: $filter.data('from'),
              to: $filter.data('to'),
            });
          } else {
            filterValues.push($(this).val());
          }
        });
        filtersObj[filterName] = filterValues;
      }
    });

    $.ajax({
      url: '/get-filters-ajax',
      type: 'post',
      dataType: 'json',
      data: filtersObj,
      beforeSend: () => {
        $('#menu_filter').addClass('loading');
      },
      success: (json) => {
        $.each(json, function getFiltersAjax(filterGroupKey, filterGroupValue) {
          const container = $(`.filter_content[id="filter_${filterGroupKey}"]`);

          $.each(filterGroupValue, function filterGroupValueEach(filterKey, filterValue) {
            let targetInput = container.find(`input[value="${filterValue.id}"]`);
            if (filterGroupKey === 'areaRanges') {
              targetInput = container.find(`input[data-from="${filterValue.from}"][data-to="${filterValue.to}"]`);
            }

            targetInput.each(function targetInputEach() {
              const $this = $(this);

              if (filterValue.checked === 1) {
                $this.attr('checked', true);
              } else {
                $this.attr('checked', false);
              }

              if (filterValue.disabled === 1) {
                $this.attr('disabled', true);
                $this.parent('label').addClass('disabled');
              } else {
                $this.attr('disabled', false);
                $this.parent('label').removeClass('disabled');
              }
            });
          });
        });
        $('#menu_filter').removeClass('loading');
      },
    });
  });

  $('#menu_filter #filters_submit').on('click', function filtersSubmitClick() {
    if (!$('#filter_areaRanges input:checked').length) {
      $('#menu_filter form').trigger('submit');
    } else {
      let counter = 1;
      $('#filter_areaRanges input:checked').each(function filterAreaRangesEach() {
        const $this = $(this);

        $this.after(`<input type="hidden" name="areaRanges[${counter}][from]" value="${$this.attr('data-from')}"/>`);
        $this.after(`<input type="hidden" name="areaRanges[${counter}][to]" value="${$this.attr('data-to')}"/>`);

        $this.attr('name', '__');
        counter += 1;
      });
      $('#menu_filter form').trigger('submit');
    }
    return false;
  });
}, 'all', '#menu_filter');
