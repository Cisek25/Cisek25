@import "../app.bundle.less";
@import "../offer.bundle.less";
@import "../_generate_less_entrypoints.js";