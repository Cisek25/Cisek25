@import "../app.bundle.less";
@import "../promotions.bundle.less";
@import "../_generate_less_entrypoints.js";