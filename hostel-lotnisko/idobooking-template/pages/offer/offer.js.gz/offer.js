// load style for page - DO NOT CHANGE !
import "./offer.less";

import "../../components/offer-top/offer-top.js";
import "../../components/offer-amenities/offer-amenities.js";
import "../../components/offer-tabs/offer-tabs.js";
import "../../components/offer-calendar/offer-calendar.js";
import "../../components/offer-gallery/offer-gallery.js";
import "../../components/offer-additional/offer-additional.js";
import "../../components/offer-prices/offer-prices.js";
import "../../components/offer-form/offer-form.js";
import "../../components/offer-advantages/offer-advantages.js";
import "../../components/side-payments/side-payments.js";
import "../../components/offer-reservation/offer-reservation.js";
import "../../components/distinguished/distinguished.js";