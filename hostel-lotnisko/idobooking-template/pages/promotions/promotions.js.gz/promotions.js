import "./promotions.less";
import "../../components/widget-search/widget-search.js";
import "../../components/side-payments/side-payments.js";
import "../../components/offers-list/offers-list.js";