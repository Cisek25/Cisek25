// load style for page - DO NOT CHANGE !
import "./opinions.less";

// template components 
import "../../components/opinions-list/opinions-list.js";
