/*
var TXT = {
    CenaOd:"{$TXT.CenaOd}",
    CenaNaTelefon:"{$TXT.CenaNaTelefon}"
};
document.addEventListener("DOMContentLoaded",function bookingStart(event){
     iai_booking_search({
        "mode":"frontpage",
        "clientId":"{$clientId}",
        "showPersons":"1",
        "showRooms":false,
        "showLocation":"1",
        "locationUrl":"/locations.js",
        "mainColor":"{$mainColor}",
        "label1":"{$TXT.Poczatek}",
        "label2":"{$TXT.Koniec}",
        "label3":"{call name=getOsoby}",
        "label4":"{call name=getObiekty}",
        "label5":"{$TXT.Lokalizacja}",
        "button":"{$TXT.SprawdzDostepnosc}",
        "months":["{$TXT.Styczen}","{$TXT.Luty}","{$TXT.Marzec}","{$TXT.Kwiecien}","{$TXT.Maj}","{$TXT.Czerwiec}","{$TXT.Lipiec}","{$TXT.Sierpien}","{$TXT.Wrzesien}","{$TXT.Pazdziernik}","{$TXT.Listopad}","{$TXT.Grudzien}"],
        "days":["{$TXT.SkrotDniaTygNd}","{$TXT.SkrotDniaTygPon}","{$TXT.SkrotDniaTygWt}","{$TXT.SkrotDniaTygSr}","{$TXT.SkrotDniaTygCzw}","{$TXT.SkrotDniaTygPt}","{$TXT.SkrotDniaTygSob}"],
        "trigger":"{$TXT.RezerwacjaOnline}",
        "lang":{$browserLang}
    });
});


*/